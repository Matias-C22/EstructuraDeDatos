#include "ColaCircular.h"
#include <iostream>

using namespace std;

ColaCircular::ColaCircular() {
    frente = nullptr;
    final = nullptr;
    tamano = 0;
}


void ColaCircular::EncolarInicio(Dato elemento) {
    Nodo* nuevo = new Nodo(elemento);
    if (Vacio()) {
        frente = nuevo;
        final = nuevo;
        nuevo->sig = nuevo;  // Apunta a s� mismo
        nuevo->ant = nuevo;  // Apunta a s� mismo
    }
    else {
        nuevo->sig = frente;
        nuevo->ant = final;
        frente->ant = nuevo;
        final->sig = nuevo;
        frente = nuevo;
    }
    tamano++;
}


//Se coloca en el final.
void ColaCircular::EncolarFinal(Dato elemento) {
    Nodo* nuevo = new Nodo(elemento);
    if (Vacio()) {
        frente = nuevo;
        final = nuevo;
        nuevo->sig = nuevo;  // Apunta a s� mismo
        nuevo->ant = nuevo;  // Apunta a s� mismo
    }
    else {
        nuevo->sig = frente;
        nuevo->ant = final;
        final->sig = nuevo;
        frente->ant = nuevo;
        final = nuevo;
    }
    tamano++;
}


void ColaCircular::DesencolarInicio() {
    if (!Vacio()) {
        Nodo* temp = frente;
        if (frente == final) {  // Solo un elemento
            frente = nullptr;
            final = nullptr;
        }
        else {
            frente = frente->sig;
            frente->ant = final;
            final->sig = frente;
        }
        delete temp;
        tamano--;
    }
    else {
        cout << "La cola est� vac�a." << endl;
    }
}

void ColaCircular::DesencolarFinal() {
    if (!Vacio()) {
        Nodo* temp = final;
        if (frente == final) {  // Solo un elemento
            frente = nullptr;
            final = nullptr;
        }
        else {
            final = final->ant;
            final->sig = frente;
            frente->ant = final;
        }
        delete temp;
        tamano--;
    }
    else {
        cout << "La cola est� vac�a." << endl;
    }
}

bool ColaCircular::Vacio() {
    return (frente == nullptr);
}

void ColaCircular::Mostrar() {
    if (Vacio()) {
        cout << "La cola est� vac�a." << endl;
        return;
    }

    Nodo* actual = frente;
    do {
        cout << "------------------------------" << endl;
        cout << "Nombre: " << actual->dato.nombre << endl;
        cout << "Apellido: " << actual->dato.apellido << endl;
        cout << "Id estudiantil: " << actual->dato.id_estudiante << endl;
        cout << "Carrera: " << actual->dato.carrera << endl;
        cout << "------------------------------" << endl;
        actual = actual->sig;
    } while (actual != frente);  // Condici�n de parada para circular
}
