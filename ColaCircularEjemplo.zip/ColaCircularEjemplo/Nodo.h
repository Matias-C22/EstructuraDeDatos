#pragma once
#include "Dato.h"

class Nodo {
public:
    Dato dato;
    Nodo* sig; //Apunta al siguiente nodo
    Nodo* ant; //Apunta al nodo anterior

    Nodo(Dato dato);
};
