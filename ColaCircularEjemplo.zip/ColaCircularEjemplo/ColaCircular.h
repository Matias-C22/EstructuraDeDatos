//Implementaci�n de la estructura de la cola doble. 
#pragma once
#include "Nodo.h"

class ColaCircular {
private:
    Nodo* frente; //Primer Nodo (apunta al primer boleto en la cola)
    Nodo* final; //�ltimo Nodo (apunta al �ltimo boleto en la cola)
    int tamano; //Cantidad de elementos (almacena el n�mero total de boletos)

public:
    ColaCircular();
    void EncolarInicio(Dato elemento);
    void EncolarFinal(Dato elemento);
    void DesencolarInicio();
    void DesencolarFinal();
    bool Vacio();
    void Mostrar();
};

