// Dato.cpp - Implementaci�n de Dato
#include "Dato.h"
Dato::Dato() {
    nombre = "";
    apellido = "";
    carrera = "";
    id_estudiante = 0;
}