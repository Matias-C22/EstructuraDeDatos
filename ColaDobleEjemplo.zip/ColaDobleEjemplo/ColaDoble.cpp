#include "ColaDoble.h"
#include <iostream>

using namespace std;

ColaDoble::ColaDoble() {
    frente = nullptr;
    final = nullptr;
    tamano = 0;
}


void ColaDoble::EncolarInicio(Dato elemento) {
    Nodo* nuevo = new Nodo(elemento);
    if (Vacio()) {
        frente = nuevo;
        final = nuevo;
    }
    else {
        nuevo->sig = frente;
        frente->ant = nuevo;
        frente = nuevo;
    }
    tamano++;
}


//Se coloca en el final.
void ColaDoble::EncolarFinal(Dato elemento) {
    Nodo* nuevo = new Nodo(elemento);
    if (Vacio()) {
        frente = nuevo;
        final = nuevo;
    }
    else {
        final->sig = nuevo;
        nuevo->ant = final;
        final = nuevo;
    }
    tamano++;
}


void ColaDoble::DesencolarInicio() {
    if (!Vacio()) {
        Nodo* temp = frente;
        frente = frente->sig;
        if (frente) 
            frente->ant = nullptr;
        else 
            final = nullptr;
        delete temp;
        tamano--;
    }
    else {
        cout << "La cola est� vac�a." << endl;
    }
}

void ColaDoble::DesencolarFinal() {
    if (!Vacio()) {
        Nodo* temp = final;
        final = final->ant;
        if (final) 
            final->sig = nullptr;
        else 
            frente = nullptr;
        delete temp;
        tamano--;
    }
    else {
        cout << "La cola est� vac�a." << endl;
    }
}

bool ColaDoble::Vacio() {
    return (frente == nullptr);
}

void ColaDoble::Mostrar() {
    Nodo* actual = frente;
    while (actual) {
        cout << "------------------------------" << endl;
        cout << "Nombre: " << actual->dato.nombre << endl;
        cout << "Apellido: " << actual->dato.apellido << endl;
        cout << "Id estudiantil: " << actual->dato.id_estudiante << endl;
        cout << "Carrera: " << actual->dato.carrera << endl;
        cout << "------------------------------" << endl;
        actual = actual->sig;  // Avanzar al siguiente nodo
    }
}
