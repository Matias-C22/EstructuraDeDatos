#include <iostream>
#include "ColaDoble.h"
#include "Dato.h"

using namespace std;

int main() {
    ColaDoble cola;
    int opcion;

    do {
        cout << "1. Encolar al inicio" << endl;
        cout << "2. Encolar al final" << endl;
        cout << "3. Desencolar del inicio" << endl;
        cout << "4. Desencolar del final" << endl;
        cout << "5. Mostrar" << endl;
        cout << "0. Salir" << endl;
        cout << "Opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            Dato d;
            cout << "Ingrese nombre: "; 
            cin >> d.nombre;
            cout << "Ingrese su apellido: "; 
            cin >> d.apellido;
            cout << "Ingrese id estudiantil: "; 
            cin >> d.id_estudiante;
            cout << "Ingrese su carrera: "; 
            cin >> d.carrera;
            cola.EncolarInicio(d);
            break;
        }
        case 2: {
            Dato d;
            cout << "Ingrese nombre: ";
            cin >> d.nombre;
            cout << "Ingrese su apellido: "; 
            cin >> d.apellido;
            cout << "Ingrese id estudiantil: "; 
            cin >> d.id_estudiante;
            cout << "Ingrese su carrera: "; 
            cin >> d.carrera;
            cola.EncolarFinal(d);
            break;
        }
        case 3:
            cola.DesencolarInicio();
            break;
        case 4:
            cola.DesencolarFinal();
            break;
        case 5:
            cola.Mostrar();
            break;
        case 0:
            cout << "Salir";
            break;
        default:
            cout << "Ingrese una opcion valida" << endl;
            break;
        }
    } while (opcion != 0);
    return 0;
}
