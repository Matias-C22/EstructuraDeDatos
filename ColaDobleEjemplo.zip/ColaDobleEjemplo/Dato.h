#pragma once
#include <string>
using namespace std;

class Dato {
public:
    string nombre;
    string apellido;
    int id_estudiante;
    string carrera;

    Dato();
};
