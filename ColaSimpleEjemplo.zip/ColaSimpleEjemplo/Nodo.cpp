#include "Nodo.h"
Nodo::Nodo(Dato dato) : dato(dato) {
    sig = nullptr;
    ant = nullptr;
}