#include <iostream>
#include "ColaSmple.h"
#include "Dato.h"

using namespace std;

int main() {
    ColaSmple cola;
    int opcion;

    do {
        cout << "1. Encolar" << endl;
        cout << "2. Desencolar" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Esta Vacia" << endl;
        cout << "0. Salir" << endl;
        cout << "Opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            Dato d;
            cout << "Ingrese su nombre: ";
            cin >> d.nombre;
            cout << "Ingrese la marca de su auto: ";
            cin >> d.marca;
            cout << "Ingrese el modelo del auto: ";
            cin >> d.modelo;
            cout << "Ingrese la placa: ";
            cin >> d.placa;
            cola.Encolar(d);
            break;
        }
        case 2:
            cola.Desencolar();
            break;
        case 3:
            cola.Mostrar();
            break;
        case 4:
            if (cola.Vacio())
                cout << "La cola esta vacia" << endl;
            else
                cout << "La cola tiene elementos" << endl;
            break;
        case 0:
            cout << "Salir";
            break;
        default:
            cout << "Ingrese una opcion valida" << endl;
            break;
        }
    } while (opcion != 0);
    return 0;
}
