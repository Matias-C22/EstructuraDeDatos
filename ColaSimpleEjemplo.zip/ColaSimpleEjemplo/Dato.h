#pragma once
#include <string>
using namespace std;

class Dato {
public:
    string nombre;
    string marca;
    string modelo;
    string placa;

    Dato();
};
