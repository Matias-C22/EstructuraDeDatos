#include "ColaSmple.h"
#include <iostream>

using namespace std;

ColaSmple::ColaSmple() {
    frente = nullptr;
    final = nullptr;
    tamano = 0;
}


void ColaSmple::Encolar(Dato elemento) {
    Nodo* nuevo = new Nodo(elemento);
    if (Vacio()) {
        frente = nuevo;
        final = nuevo;
    }
    else {
        final->sig = nuevo;
        nuevo->ant = final;
        final = nuevo;
    }
    tamano++;
}


void ColaSmple::Desencolar() {
    if (!Vacio()) {
        Nodo* temp = frente;
        frente = frente->sig;
        if (frente)
            frente->ant = nullptr;
        else
            final = nullptr;
        delete temp;
        tamano--;
    }
    else {
        cout << "La cola est� vac�a." << endl;
    }
}

bool ColaSmple::Vacio() {
    return (frente == nullptr);
}

void ColaSmple::Mostrar() {
    Nodo* actual = frente;
    while (actual) {
        cout << "------------------------------" << endl;
        cout << "Nombre: " << actual->dato.nombre << endl;
        cout << "Marca: " << actual->dato.marca << endl;
        cout << "Modelo: " << actual->dato.modelo << endl;
        cout << "Placa: " << actual->dato.placa << endl;
        cout << "------------------------------" << endl;
        actual = actual->sig;  // Avanzar al siguiente nodo
    }
}
