#include "Cuadrado.h"
Cuadrado::Cuadrado() {


}
float Cuadrado::get_ladoCuadrado() {
    return ladoCuadrado;
}


void Cuadrado::set_ladoCuadrado(float _ladoCuadrado) {
    ladoCuadrado = _ladoCuadrado;
}
double Cuadrado::AreaCuadrado() {
    return ladoCuadrado * ladoCuadrado;
}
