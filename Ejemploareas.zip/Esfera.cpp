#include "Esfera.h"
#include <math.h>

Esfera::Esfera() {}

float Esfera::get_radio() {
	return radioEsfera;
}

void  Esfera::set_radio(float _radio) {
	radioEsfera = _radio;
}

double Esfera::AreaEsfera() {
	return 4 * 3.1415926 * radioEsfera * radioEsfera;
}
